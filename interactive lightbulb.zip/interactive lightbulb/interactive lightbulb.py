# -*- coding: utf-8 -*-
"""
Created on Sat Nov 27 14:26:16 2021

@author: ericd
"""


"""The goal is to make a lightbulb that could light up multiple colors"""

import turtle
from pydub import AudioSegment
from pydub.playback import play

song = AudioSegment.from_wav("2.wav")
play(song)
# =================== LIBRARY SETTINGS SETUP =========================
# turtle.colormode(255) # accept 0-255 RGB values
# turtle.tracer(0) # turn off turtle's animation

# panel = turtle.Screen()
# w = 800
# h = 800
# panel.setup(width=w, height=h)
#panel.bgcolor("black")

# ================ VARIABLE DEFINITION & SETUP =======================
"""The objective here is to make an RGB lightbulb that is connected corresponding buttons"""

"""MAKING THE LIGHTBULB"""
# turtle.pendown()
# turtle.goto(0,100)
# lightbulb = turtle.circle(50)
# turtle.penup()
# turtle.pendown()
# turtle.goto(0,0)
# turtle.shape("square")
# turtle.penup()
# turtle.pendown()
# turtle.goto(0,-50)
# turtle.shape("square")
# turtle.penup()
# turtle.pendown()
# turtle.goto(0,-100)
# turtle.shape("square")

#turtle.mainloop()
#turtle.done()





tr = turtle.Turtle()
wn = turtle.Screen()
wn.addshape('1.gif')
tr.shape('1.gif')
#wn.mainloop()









